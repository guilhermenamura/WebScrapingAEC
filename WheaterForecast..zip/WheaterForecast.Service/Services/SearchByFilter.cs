using System.Diagnostics;
using WheaterForecast.Domain.Interfaces.SearchByFilter;

namespace WheaterForecast.Service.Services;

public class SearchByFilter : ISearchByFilter
{
    private readonly HttpClient _httpClient;

    public SearchByFilter(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }
    public async Task<dynamic> GetbyCoordinate(string latitude, string longitude)
    {
        try
        {
            string apiKey = "e96674411b3432dbe77271d9ee656151";
            string url =
                $"https://api.openweathermap.org/data/2.5/forecast?lat={latitude}&long={longitude}&appid={apiKey}";
            HttpResponseMessage responseMessage = await _httpClient.GetAsync(url);

            if (responseMessage.IsSuccessStatusCode)
            {
                string content = await responseMessage.Content.ReadAsStringAsync();
                return content;
            }
            else
            {
                return string.Concat(responseMessage.StatusCode," Erro ao obter os dados da previsão do tempo");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
            throw;
        }
    }
}