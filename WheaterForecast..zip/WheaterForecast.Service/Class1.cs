﻿namespace WheaterForecast.Service;

public class Class1
{
}