# WeatherForecast_Backend
Display Weather Forecast by location for 5 days. This Repository contains the backend responsible for consuming the Source Api and delivering it to the Frontend.
