using Microsoft.AspNetCore.Mvc;
using WheaterForecast.Application.Service;

namespace WheaterForecast.Application.Controllers;

[ApiController]
[Route("[controller]")]
public class WeatherForecastController : ControllerBase
{
    private readonly ILogger<WeatherForecastController> _logger;
    private readonly ISearchWeatherForecast _searchWeatherForecast; 
    public WeatherForecastController(ILogger<WeatherForecastController> logger,
                                     ISearchWeatherForecast searchWeatherForecast)
    {
        _logger = logger;
        _searchWeatherForecast = searchWeatherForecast;
    }

    [HttpGet(Name = "GetWeatherForecast")]
    public StatusCodeResult Get(string latitude, string longitude)
    {
        var response = _searchWeatherForecast.SearchWeatherForecastByCoordinates(latitude, longitude);
        return Ok();
    }
}