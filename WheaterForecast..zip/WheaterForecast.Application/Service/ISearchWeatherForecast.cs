namespace WheaterForecast.Application.Service;

public interface ISearchWeatherForecast
{
    dynamic SearchWeatherForecastByCoordinates(string latitude, string longitude);
}
