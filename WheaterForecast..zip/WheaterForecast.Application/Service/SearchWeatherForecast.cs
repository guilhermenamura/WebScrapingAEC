using WheaterForecast.Domain.Interfaces.SearchByFilter;

namespace WheaterForecast.Application.Service;

public class SearchWeatherForecast : ISearchWeatherForecast
{
    private readonly ISearchByFilter _searchByFilter;

    public SearchWeatherForecast(ISearchByFilter searchByFilter)
    {
        _searchByFilter = searchByFilter;
    }
    public dynamic SearchWeatherForecastByCoordinates(string latitude, string longitude)
    {
        return _searchByFilter.GetbyCoordinate(latitude, longitude);
    }
}