namespace WheaterForecast.Domain.Entities;

public class SearchOriginRunHistoryEntity : BaseEntity
{
    public string Payload { get; set; }
    public string Response { get; set; }
}