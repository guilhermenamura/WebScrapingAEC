using System.ComponentModel.DataAnnotations;
namespace WheaterForecast.Domain.Entities;

public abstract class BaseEntity {
    
    [Key]
    public Guid Id { get; set; }

    private readonly DateTime _runAt = DateTime.UtcNow;
    public DateTime RunAt
    {
        get => _runAt;
        set => throw new NotImplementedException();
    }
}