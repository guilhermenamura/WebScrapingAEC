﻿namespace WheaterForecast.Domain;

public class Class1
{
}