namespace WheaterForecast.Domain.Interfaces.SearchByFilter;

public interface ISearchByFilter
{
    Task<dynamic> GetbyCoordinate(string latitude, string longitude);
}